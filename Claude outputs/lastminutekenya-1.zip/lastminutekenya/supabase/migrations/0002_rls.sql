-- LastMinuteKenya — Row Level Security
-- Run after 0001_schema.sql. House-style rule: the anon key may INSERT to public
-- forms but must NOT SELECT PII. Providers/assessors/clients each see only what
-- they need; the alerts table is written only by the service role.

-- ---------------------------------------------------------------------------
-- Role helpers (SECURITY DEFINER so reading the caller's role does not recurse
-- through profiles' own RLS).
-- ---------------------------------------------------------------------------
create or replace function public.my_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid()
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() = 'admin', false)
$$;

-- The provider row id belonging to the current user (for provider policies).
create or replace function public.my_provider_id()
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.providers where profile_id = auth.uid() limit 1
$$;

-- The assessor row id belonging to the current user.
create or replace function public.my_assessor_id()
returns uuid language sql stable security definer set search_path = public as $$
  select id from public.assessors where profile_id = auth.uid() limit 1
$$;

-- ---------------------------------------------------------------------------
-- Enable RLS everywhere.
-- ---------------------------------------------------------------------------
alter table public.profiles     enable row level security;
alter table public.providers    enable row level security;
alter table public.assessors    enable row level security;
alter table public.events       enable row level security;
alter table public.assessments  enable row level security;
alter table public.sos_jobs     enable row level security;
alter table public.alerts       enable row level security;

-- profiles -------------------------------------------------------------------
create policy profiles_self_read   on public.profiles for select
  using (id = auth.uid() or public.is_admin());
create policy profiles_self_update on public.profiles for update
  using (id = auth.uid());

-- providers ------------------------------------------------------------------
-- Base table (with PII) is readable only by the owner + admin. The public view
-- providers_public exposes the safe columns to everyone (see grants below).
create policy providers_owner_read on public.providers for select
  using (profile_id = auth.uid() or public.is_admin());
create policy providers_owner_update on public.providers for update
  using (profile_id = auth.uid() or public.is_admin());
create policy providers_admin_insert on public.providers for insert
  with check (public.is_admin());

-- assessors ------------------------------------------------------------------
create policy assessors_read on public.assessors for select
  using (profile_id = auth.uid() or public.is_admin());
create policy assessors_admin_write on public.assessors for all
  using (public.is_admin()) with check (public.is_admin());

-- events ---------------------------------------------------------------------
create policy events_owner_read on public.events for select
  using (
    client_id = auth.uid()
    or public.is_admin()
    or exists (
      select 1 from public.assessments a
      where a.event_id = events.id and a.assessor_id = public.my_assessor_id()
    )
  );
create policy events_client_insert on public.events for insert
  with check (client_id = auth.uid());
create policy events_owner_update on public.events for update
  using (client_id = auth.uid() or public.is_admin());

-- assessments ----------------------------------------------------------------
create policy assessments_read on public.assessments for select
  using (
    requested_by = auth.uid()
    or public.is_admin()
    or assessor_id = public.my_assessor_id()
  );
create policy assessments_client_insert on public.assessments for insert
  with check (requested_by = auth.uid());
-- Assigned assessor (or admin) fills in the scorecard.
create policy assessments_assessor_update on public.assessments for update
  using (assessor_id = public.my_assessor_id() or public.is_admin());

-- sos_jobs -------------------------------------------------------------------
-- Providers see open jobs in a category they serve; clients see their own;
-- admins see all.
create policy sos_read on public.sos_jobs for select
  using (
    public.is_admin()
    or exists (select 1 from public.events e where e.id = sos_jobs.event_id and e.client_id = auth.uid())
    or (
      status <> 'resolved'
      and exists (
        select 1 from public.providers p
        where p.profile_id = auth.uid() and sos_jobs.category = any (p.categories)
      )
    )
  );
create policy sos_client_insert on public.sos_jobs for insert
  with check (
    public.is_admin()
    or exists (select 1 from public.events e where e.id = event_id and e.client_id = auth.uid())
  );
-- A provider accepts (sets accepted_by to their own provider id); admin can too.
create policy sos_accept_update on public.sos_jobs for update
  using (public.is_admin() or category in (select unnest(categories) from public.providers where profile_id = auth.uid()))
  with check (public.is_admin() or accepted_by = public.my_provider_id());

-- alerts ---------------------------------------------------------------------
-- Providers read their own alerts and may acknowledge them; admin reads all.
-- INSERTs come from the service role (edge function), which bypasses RLS.
create policy alerts_provider_read on public.alerts for select
  using (provider_id = public.my_provider_id() or public.is_admin());
create policy alerts_provider_ack on public.alerts for update
  using (provider_id = public.my_provider_id() or public.is_admin());

-- ---------------------------------------------------------------------------
-- Grants: expose ONLY the public view to anon (and authenticated). The base
-- providers table's PII stays behind RLS above.
-- ---------------------------------------------------------------------------
grant select on public.providers_public to anon, authenticated;
