import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

// LastMinuteKenya — Vite + React + installable PWA.
// House style: register with autoUpdate; keep static pages that must bypass the
// SPA shell (privacy.html) in navigateFallbackDenylist so the service worker
// serves the real file instead of the app shell.
export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.svg', 'icons/icon.svg', 'privacy.html'],
      manifest: {
        name: 'LastMinuteKenya',
        short_name: 'LastMinute',
        description:
          'When an event provider flops, the Last Minute Network steps in. Request rescue, book a Site Assessor, get a Red/Amber/Green scorecard.',
        theme_color: '#1f2a44',
        background_color: '#f7f5f0',
        display: 'standalone',
        orientation: 'portrait',
        start_url: '/',
        scope: '/',
        categories: ['business', 'productivity', 'lifestyle'],
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png' },
          {
            src: 'icons/icon-maskable-512.png',
            sizes: '512x512',
            type: 'image/png',
            purpose: 'maskable',
          },
        ],
      },
      workbox: {
        // privacy.html is a real static page, not an SPA route — don't let the
        // app shell hijack it.
        navigateFallbackDenylist: [/^\/privacy\.html$/],
        globPatterns: ['**/*.{js,css,html,svg,png,webmanifest,woff2}'],
      },
    }),
  ],
})
