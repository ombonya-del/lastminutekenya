import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { Routes, Route, NavLink, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { Icon, Sheet, Avatar } from './components/ui.jsx'
import { useStore, clearToast } from './data/store.js'
import { supabaseEnabled } from './lib/supabase.js'
import { signInStaff, signUpStaff, signOut, onAuthChange } from './lib/auth.js'
import { whoami } from './data/api.js'
import { PublicShell } from './surfaces/Public.jsx'
import { NetworkShell } from './surfaces/Network.jsx'
import { CommandShell } from './surfaces/Command.jsx'
import { FieldShell } from './surfaces/Field.jsx'

// ---- role + identity context ----------------------------------------------
const AppCtx = createContext(null)
export const useApp = () => useContext(AppCtx)

const ROLES = {
  customer: {
    label: 'Customer',
    tagline: 'Public PWA',
    nav: [
      { to: '/customer', icon: 'home', label: 'Home', end: true },
      { to: '/customer/help', icon: 'alert', label: 'Get Help' },
      { to: '/customer/requests', icon: 'clipboard', label: 'Requests' },
    ],
  },
  provider: {
    label: 'Provider',
    tagline: 'Last Minute Network',
    nav: [
      { to: '/provider', icon: 'spark', label: 'Network', end: true },
      { to: '/provider/jobs', icon: 'alert', label: 'Rescues' },
      { to: '/provider/profile', icon: 'users', label: 'Profile' },
    ],
  },
  assessor: {
    label: 'Assessor',
    tagline: 'Site Assessment',
    nav: [
      { to: '/assessor', icon: 'clipboard', label: 'Visits', end: true },
      { to: '/assessor/account', icon: 'users', label: 'Account' },
    ],
  },
  admin: {
    label: 'Admin',
    tagline: 'Operations',
    nav: [
      { to: '/admin', icon: 'grid', label: 'Overview', end: true },
      { to: '/admin/scorecards', icon: 'shield', label: 'Scorecards' },
      { to: '/admin/dispatch', icon: 'send', label: 'Dispatch' },
      { to: '/admin/network', icon: 'map', label: 'Network' },
      { to: '/admin/accounts', icon: 'users', label: 'Accounts' },
    ],
  },
}

function roleFromPath(pathname) {
  const seg = pathname.split('/')[1]
  return ROLES[seg] ? seg : 'customer'
}

export default function App() {
  const location = useLocation()
  const navigate = useNavigate()
  const [switcher, setSwitcher] = useState(false)
  const [login, setLogin] = useState(false)
  const [previewRole, setPreviewRole] = useState(null)

  // Demo identities (seed mode only — switchable in the UI).
  const [demoProviderId, setDemoProviderId] = useState('p_savanna')
  const [demoAssessorId, setDemoAssessorId] = useState('a_atieno')

  // Live identity (from Supabase whoami).
  const [identity, setIdentity] = useState(null)
  const [authReady, setAuthReady] = useState(!supabaseEnabled)

  useEffect(() => {
    if (!supabaseEnabled) return
    let alive = true
    const load = () =>
      whoami().then((w) => {
        if (alive) {
          setIdentity(w)
          setAuthReady(true)
        }
      })
    load()
    const off = onAuthChange(load)
    return () => {
      alive = false
      off()
    }
  }, [])

  const realRole = supabaseEnabled ? identity?.role || 'customer' : roleFromPath(location.pathname)
  const role = previewRole || realRole

  // In live mode the URL must match the signed-in user's role (unless previewing).
  useEffect(() => {
    if (!supabaseEnabled || !identity || previewRole) return
    const seg = location.pathname.split('/')[1]
    if (seg !== realRole) navigate('/' + realRole, { replace: true })
  }, [identity, realRole, previewRole, location.pathname])

  const ctx = useMemo(
    () => ({
      role,
      live: supabaseEnabled,
      providerId: supabaseEnabled ? identity?.providerId : demoProviderId,
      assessorId: supabaseEnabled ? identity?.assessorId : demoAssessorId,
      clientId: supabaseEnabled ? identity?.uid : 'c_wanjiru',
      setProviderId: setDemoProviderId,
      setAssessorId: setDemoAssessorId,
    }),
    [role, identity, demoProviderId, demoAssessorId]
  )

  const cfg = ROLES[role]

  if (!authReady) {
    return (
      <div className="app">
        <div className="empty" style={{ paddingTop: '40vh' }}>
          <Icon name="clock" size={40} />
          <div className="subtitle" style={{ marginTop: '.4rem' }}>Connecting…</div>
        </div>
      </div>
    )
  }

  const openStaff = () => setSwitcher(true)

  return (
    <AppCtx.Provider value={ctx}>
      {role === 'customer' ? (
        <PublicShell onStaff={openStaff} />
      ) : role === 'provider' ? (
        <NetworkShell onStaff={openStaff} />
      ) : role === 'admin' ? (
        <CommandShell onStaff={openStaff} />
      ) : (
        <FieldShell onStaff={openStaff} />
      )}

      {switcher && !supabaseEnabled && (
        <RoleSwitcher current={role} onPick={(r) => { setSwitcher(false); navigate('/' + r) }} onClose={() => setSwitcher(false)} />
      )}
      {switcher && supabaseEnabled && (
        <AccountMenu identity={identity} role={role} realRole={realRole}
          onSignIn={() => { setSwitcher(false); setLogin(true) }}
          onSignOut={async () => { setSwitcher(false); setPreviewRole(null); await signOut() }}
          onPreview={(r) => { setSwitcher(false); setPreviewRole(r === realRole ? null : r); navigate('/' + r) }}
          onClose={() => setSwitcher(false)} />
      )}
      {previewRole && (
        <div style={{ position: 'fixed', top: 0, left: '50%', transform: 'translateX(-50%)', zIndex: 80, maxWidth: 640, width: '100%' }}>
          <div style={{ background: '#ffd400', color: '#000', fontWeight: 900, fontSize: '.74rem', textTransform: 'uppercase', letterSpacing: '.06em', textAlign: 'center', padding: '.4rem .6rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '.6rem' }}>
            Previewing: {ROLES[previewRole]?.label} ecosystem
            <button onClick={() => { setPreviewRole(null); navigate('/' + realRole) }} style={{ background: 'rgba(0,0,0,.85)', color: '#fff', border: 'none', borderRadius: 6, padding: '.2rem .6rem', fontWeight: 800, fontSize: '.7rem', cursor: 'pointer' }}>Exit</button>
          </div>
        </div>
      )}
      {login && <StaffLogin onClose={() => setLogin(false)} />}
    </AppCtx.Provider>
  )
}

function TopBar({ cfg, live, identity, onOpen }) {
  const label = live ? (identity?.email ? cfg.label : 'Guest') : cfg.label
  return (
    <header className="topbar">
      <div className="brand">
        <img src="/favicon.svg" width="26" height="26" alt="" style={{ borderRadius: 7 }} />
        <span><span className="lm">LastMinute</span><span className="ke">KE</span></span>
      </div>
      <div className="spacer" />
      <button className="chip brand" onClick={onOpen} style={{ cursor: 'pointer' }}>
        {label}
        <Icon name="chevron" size={14} style={{ transform: 'rotate(90deg)' }} />
      </button>
    </header>
  )
}

function BottomNav({ cfg }) {
  const s = useStore()
  const { providerId } = useApp()
  const providerUnread = s.alertsLog.filter((a) => a.providerId === providerId && !a.acknowledged).length
  const openJobs = s.sosJobs.filter((j) => j.status !== 'resolved').length

  const badgeFor = (item) => {
    if (item.to === '/provider' && providerUnread) return providerUnread
    if (item.to === '/provider/jobs' && openJobs) return openJobs
    if (item.to === '/admin/dispatch' && openJobs) return openJobs
    return null
  }

  return (
    <nav className="bottomnav" aria-label="Primary">
      {cfg.nav.map((item) => {
        const badge = badgeFor(item)
        return (
          <NavLink key={item.to} to={item.to} end={item.end} className={({ isActive }) => (isActive ? 'active' : '')}>
            {badge ? <span className="badge">{badge}</span> : null}
            <Icon name={item.icon} size={22} />
            {item.label}
          </NavLink>
        )
      })}
    </nav>
  )
}

function RoleSwitcher({ current, onPick, onClose }) {
  return (
    <Sheet title="Viewing as" onClose={onClose}>
      <p className="caption" style={{ marginTop: 0 }}>
        One prototype, four surfaces. Switch the lens to see the same live data from each side of the network.
      </p>
      <div style={{ display: 'grid', gap: '.6rem', marginTop: '.6rem' }}>
        {Object.entries(ROLES).map(([key, r]) => (
          <button
            key={key}
            className="card flat"
            onClick={() => onPick(key)}
            style={{
              display: 'flex', alignItems: 'center', gap: '.8rem', textAlign: 'left', cursor: 'pointer',
              borderColor: key === current ? 'var(--brand-2)' : 'var(--line)',
              boxShadow: key === current ? '0 0 0 1px var(--brand-2) inset' : 'none',
            }}
          >
            <div className="avatar" style={{ background: 'var(--brand)' }}>
              <Icon name={ROLES[key].nav[0].icon} size={20} style={{ color: '#fff' }} />
            </div>
            <div className="grow">
              <div className="subtitle">{r.label}</div>
              <div className="caption">{r.tagline}</div>
            </div>
            {key === current && <Icon name="check" size={20} style={{ color: 'var(--brand-2)' }} />}
          </button>
        ))}
      </div>
    </Sheet>
  )
}

function AccountMenu({ identity, role, realRole, onSignIn, onSignOut, onPreview, onClose }) {
  const isGuest = !identity?.email
  return (
    <Sheet title="Account" onClose={onClose}>
      <div className="card flat" style={{ display: 'flex', alignItems: 'center', gap: '.8rem' }}>
        <Avatar name={identity?.email || 'Guest'} />
        <div className="grow">
          <div className="subtitle wrapany">{identity?.email || 'Guest (anonymous)'}</div>
          <div className="caption">Signed in as <strong>{ROLES[realRole]?.label}</strong></div>
        </div>
      </div>

      {realRole === 'admin' && (
        <>
          <div className="caption" style={{ fontWeight: 800, margin: '.9rem .1rem .4rem' }}>Preview ecosystems</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2,1fr)', gap: '.5rem' }}>
            {[['customer', 'Public · Clients'], ['provider', 'Network · Providers'], ['assessor', 'Field · Assessors'], ['admin', 'Command · Admin']].map(([k, label]) => (
              <button key={k} className="btn btn-ghost btn-sm" style={{ width: '100%', justifyContent: 'flex-start' }} onClick={() => onPreview(k)}>{label}</button>
            ))}
          </div>
          <div className="caption" style={{ margin: '.4rem .1rem 0' }}>See each surface as its stakeholder does. Exit returns you to Command.</div>
        </>
      )}

      {isGuest && (
        <button className="btn btn-dark" style={{ marginTop: '.8rem' }} onClick={onSignIn}>
          <Icon name="users" size={18} /> Staff sign in / register
        </button>
      )}
      <button className="btn btn-ghost" style={{ marginTop: '.5rem' }} onClick={onSignOut}>
        {isGuest ? 'Reset session' : 'Sign out'}
      </button>
    </Sheet>
  )
}

function StaffLogin({ onClose }) {
  const [mode, setMode] = useState('in') // 'in' | 'up'
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [requestedRole, setRequestedRole] = useState('provider')
  const [busy, setBusy] = useState(false)
  const [err, setErr] = useState('')
  const [done, setDone] = useState(null) // 'confirm' | 'created'

  const submit = async () => {
    setBusy(true)
    setErr('')
    if (mode === 'in') {
      const { error } = await signInStaff(email, password)
      setBusy(false)
      if (error) setErr(typeof error === 'string' ? error : error.message)
      else onClose()
    } else {
      const { error, needsConfirm } = await signUpStaff({ name, email, password, requestedRole })
      setBusy(false)
      if (error) setErr(typeof error === 'string' ? error : error.message)
      else setDone(needsConfirm ? 'confirm' : 'created')
    }
  }

  if (done) {
    return (
      <Sheet title="Request sent" onClose={onClose}>
        <div style={{ textAlign: 'center', padding: '.5rem 0 .3rem' }}>
          <div className="avatar" style={{ background: 'var(--green)', margin: '0 auto .6rem', width: 48, height: 48 }}>
            <Icon name="check" size={24} style={{ color: '#fff' }} />
          </div>
          <div className="subtitle">Account created</div>
          <p className="body" style={{ marginTop: '.4rem' }}>
            {done === 'confirm'
              ? 'Check your email to confirm the address, then an admin will grant your access.'
              : `Thanks${name ? ', ' + name : ''}. An admin will review and grant your ${requestedRole} access shortly.`}
          </p>
          <button className="btn btn-primary" style={{ marginTop: '.9rem' }} onClick={onClose}>Done</button>
        </div>
      </Sheet>
    )
  }

  return (
    <Sheet title={mode === 'in' ? 'Staff sign in' : 'Request staff access'} onClose={onClose}>
      <div className="optiongrid" style={{ marginBottom: '.4rem' }}>
        <button className={`optionbtn ${mode === 'in' ? 'on' : ''}`} style={{ justifyContent: 'center' }} onClick={() => { setMode('in'); setErr('') }}>Sign in</button>
        <button className={`optionbtn ${mode === 'up' ? 'on' : ''}`} style={{ justifyContent: 'center' }} onClick={() => { setMode('up'); setErr('') }}>Request access</button>
      </div>
      <p className="caption" style={{ marginTop: 0 }}>
        {mode === 'in'
          ? "For providers, assessors and admins. Customers don't need an account."
          : 'Providers and assessors: register here. An admin approves before you get access.'}
      </p>

      {mode === 'up' && (
        <>
          <div className="field">
            <label>Name / business name</label>
            <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Savanna Fresh Caterers" />
          </div>
          <div className="field">
            <label>I'm signing up as</label>
            <div className="optiongrid">
              <button className={`optionbtn ${requestedRole === 'provider' ? 'on' : ''}`} onClick={() => setRequestedRole('provider')}>
                <Icon name="spark" size={16} /> Provider
              </button>
              <button className={`optionbtn ${requestedRole === 'assessor' ? 'on' : ''}`} onClick={() => setRequestedRole('assessor')}>
                <Icon name="clipboard" size={16} /> Assessor
              </button>
            </div>
          </div>
        </>
      )}

      <div className="field">
        <label>Email</label>
        <input className="input" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
      </div>
      <div className="field">
        <label>Password</label>
        <input className="input" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder={mode === 'up' ? 'At least 6 characters' : ''} />
      </div>
      {err && <p className="caption" style={{ color: 'var(--red)', marginTop: '.5rem' }}>{err}</p>}
      <button className="btn btn-primary" style={{ marginTop: '1rem' }}
        disabled={busy || !email || !password || (mode === 'up' && !name)} onClick={submit}>
        {busy ? 'Please wait…' : mode === 'in' ? 'Sign in' : 'Create account'}
      </button>
    </Sheet>
  )
}

function Toaster() {
  const s = useStore()
  if (!s.toast) return null
  setTimeout(clearToast, 3200)
  return (
    <div
      role="status"
      style={{
        position: 'fixed', left: '50%', transform: 'translateX(-50%)',
        bottom: 'calc(var(--nav-h) + env(safe-area-inset-bottom) + 12px)', zIndex: 70,
        maxWidth: 'calc(var(--maxw) - 24px)', width: 'max-content',
        background: 'var(--brand)', color: '#fff', padding: '.7rem 1rem', borderRadius: 12,
        boxShadow: 'var(--shadow-lift)', fontWeight: 700, fontSize: '.88rem',
        display: 'flex', gap: '.5rem', alignItems: 'center',
      }}
    >
      <Icon name="check" size={18} style={{ color: 'var(--brand-2)' }} />
      {s.toast.msg}
    </div>
  )
}
